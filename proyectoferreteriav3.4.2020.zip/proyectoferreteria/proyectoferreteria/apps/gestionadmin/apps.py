from django.apps import AppConfig


class GestionadminConfig(AppConfig):
    name = 'gestionadmin'
