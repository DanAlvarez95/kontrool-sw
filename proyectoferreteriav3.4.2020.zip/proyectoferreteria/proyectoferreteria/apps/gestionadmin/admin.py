from django.contrib import admin
from proyectoferreteria.apps.gestionadmin.models import FormaPago, MetodoPago, Garantia, Marca, Categoria, Proveedor,Cliente, Planilla, Empleado, Producto, FacturaDetalle, FacturaEncabezado, TurnoEmpleado
# Register your models here.
admin.site.register(Marca)
admin.site.register(Categoria)
admin.site.register(Proveedor)
admin.site.register(Garantia)
admin.site.register(FormaPago)
admin.site.register(MetodoPago)
admin.site.register(Cliente)
admin.site.register(Planilla)
admin.site.register(Empleado)
admin.site.register(Producto)
admin.site.register(FacturaDetalle)
admin.site.register(FacturaEncabezado)
admin.site.register(TurnoEmpleado)


