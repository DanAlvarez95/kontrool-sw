from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.urls import reverse_lazy
from proyectoferreteria.apps.gestionadmin.formularios.marca_form import MarcaForm
from proyectoferreteria.apps.gestionadmin.models import Marca
from django.urls import reverse
from django.core.paginator import Paginator

from django.views.generic import ListView, CreateView, UpdateView, DeleteView


def vista_principal(request):
    return render(request,'base/baseprincipal.html')

def marca_index(request):
    listaE = Marca.objects.all()
    contexto = {'lista': listaE}
    return render(request, 'gestionadmin/indexmarca.html', contexto)

    
def marca_nueva(request):
    if request.method == 'POST':
        form = MarcaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('Marca_index') 
    else:
        form = MarcaForm()
    return render(request, 'gestionadmin/formmarca.html', {'form':form})

def marca_edit(request, id_exp):
    exp = Marca.objects.get(idMarca=id_exp)
    if request.method == 'GET':
        
        form = MarcaForm(instance=exp)
    else:
        form = MarcaForm(request.POST, instance=exp)
        if form.is_valid():
            form.save()
        return redirect('Marca_index') 
    return render(request, 'gestionadmin/formmarca.html', {'form':form})

def marca_delete(request, id_exp):
    exp = Marca.objects.get(idMarca=id_exp)
    if request.method == 'POST':
        exp.delete()
        return redirect('Marca_index') 
    return render(request, 'gestionadmin/formmarca.html', {'Clientes':exp})    

