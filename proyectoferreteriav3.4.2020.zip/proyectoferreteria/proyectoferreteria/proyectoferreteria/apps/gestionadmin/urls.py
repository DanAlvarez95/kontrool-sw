from django.urls import path
from proyectoferreteria.apps.gestionadmin.views import marca_index, marca_nueva, marca_edit, marca_delete, vista_principal


urlpatterns = [
    path('gestionadmin/vistaprincipal',vista_principal, name='Vista_principal'),
    path('marca/index', marca_index, name='Marca_index'),
    path('marca/nueva', marca_nueva, name='Marca_crear'),
    path('marca/editar/<int:id_exp>/', marca_edit, name='Marca_editar'),
    path('marca/eliminar/<int:id_exp>/', marca_delete, name='Marca_delete'),
]
