from django.db import models
import datetime
from django.utils import timezone

# Create your models here.
from django.core.exceptions import ValidationError
def validar_mayor_a_tres(value):
    if value<3:
        raise ValidationError('Numero debe ser mayor que 2')

def validarquenoseacero(value):
    if(value)<1:
         raise ValidationError('Numero debe ser mayor que 1')

def validarsueldo(value):
    if value<1000:
        raise ValidationError('Sueldo invalido debe ser mayor a 999')
    if value>200000:
        raise ValidationError('Sueldo invalido debe ser menor a 200000')

def validarhora(value):
    lista=[]
    for indice in value:
        lista.append(indice)
    if lista[2]!=":":
        raise ValidationError('Hora inválida el formato es por ejemplo: 12:45')
    if not (len(value)) > 4:
        raise ValidationError('Hora incorrecta el formato es por ejemplo: 12:45')
    if lista[0]=="3" or lista[0]=="4" or lista[0]=="5" or lista[0]=="6" or lista[0]=="7" or lista[0]=="8" or lista[0]=="9":
        raise ValidationError('Hora incorrecta el formato es por ejemplo: 12:45')


def validarnombre(value):
    lista=[]
    for indice in value:
        lista.append(indice)
    
    if (len(lista))<3:
        raise ValidationError('El texto es inválido debe ser mayor a 3 caracteres, digite de nuevo')
    
    if lista[0]=="a" and lista [1]=="b" and lista[2]=="c":
        raise ValidationError('El texto debe ser valido digite de nuevo')


    lista=[]
    vocal=["a","e","i","o","u","á","é","í","ó","ú"]
    cont=0
    for i in vocal:
        for j in value:
            if(i==j):
                cont+=1
    if(cont<1):
     raise ValidationError('El texto es inválido, digite de nuevo')   
    
def validardireccion(value):
    lista=[]
    for indice in value:
        lista.append(indice)
    if lista[0]=="a" and lista [1]=="b" and lista[2]=="c":
        raise ValidationError('La direccion debe ser válida digite de nuevo')

    if lista[0]=="." or lista[1]==",":
       raise ValidationError('La direccion no puede contener un punto al inicio')
     
def validarnumero(value):
    numeros=[]
    for indice in value:
        numeros.append(indice)
        
    if ((numeros[0]=="0") or (numeros[0]=="1") or (numeros[0]=="4") or (numeros[0]=="5") or (numeros[0]=="6") or (numeros[0]=="7")):
        raise ValidationError('El numero no es válido, intente de nuevo')
    if(len(numeros))<8:
        raise ValidationError('El numero debe contener al menos 8 digitos, intente de nuevo')
    if("-" in numeros or ("." in numeros)):
        raise ValidationError('El numero debe contener al menos 8 digitos, ejemplo 99234567')

def validartamaño(value):
    if  value<1:
        raise ValidationError('El numero no puede ser menor a 0')
    if  value>999999999:
        raise ValidationError('El numero no puede ser mayor a 9 digitos')

class Marca (models.Model):
    idMarca=models.IntegerField(primary_key=True, validators=[validartamaño])
    nombreMarca= models.CharField(max_length=30, validators=[validarnombre])
    def __str__(self):
        return '{}'.format(str(self.idMarca)+" "+self.nombreMarca)
    
    

class Categoria (models.Model):
    idCategoria=models.IntegerField(primary_key=True, validators=[validartamaño])
    descripcionCategoria=models.CharField(max_length=30,validators=[validarnombre])

    def __str__(self):
        return '{}'.format(str(self.idCategoria)+" "+self.descripcionCategoria)

class Proveedor (models.Model):
    idProveedor = models.IntegerField(primary_key=True, validators=[validartamaño])
    nombreProveedor=models.CharField(max_length=35,validators=[validarnombre])
    correoProveedor=models.EmailField(max_length=30, blank=True)
    direccionProveedor=models.TextField(max_length=30, validators=[validardireccion])
    telefonoProveedor=models.CharField(max_length=8, validators=[validarnumero])

    def __str__(self):
        return '{}'.format(str(self.idProveedor)+" "+self.nombreProveedor)

class Garantia (models.Model):
    idGarantia = models.IntegerField(primary_key=True, validators=[validartamaño])
    descripcionGarantia=models.TextField()
    tiempoGarantiaMes=models.IntegerField()

    def __str__(self):
        return '{}'.format(str(self.idGarantia)+" "+self.descripcionGarantia)

class FormaPago(models.Model):
    idFormaPago=models.IntegerField(primary_key=True, validators=[validartamaño])
    descripcionFormaPago=models.TextField(max_length=30,validators=[validarnombre])
    def __str__(self):
        return '{}'.format(str(self.idFormaPago)+" "+self.descripcionFormaPago)

class MetodoPago(models.Model):
    idMetodoPago=models.IntegerField(primary_key=True, validators=[validartamaño])
    descripcionMetodoPago=models.TextField(max_length=30, validators=[validarnombre])
    def __str__(self):
        return '{}'.format(str(self.idMetodoPago)+" "+self.descripcionMetodoPago)

class Cliente(models.Model):
    idCliente=models.IntegerField(primary_key=True, validators=[validartamaño])
    nombreCliente=models.CharField(max_length=30, validators=[validarnombre])
    correoCliente=models.EmailField(max_length=30, blank=True)
    direccionCliente=models.TextField(max_length=100, validators=[validardireccion])
    telefonoCliente=models.CharField(max_length=8, validators=[validarnumero])

    def __str__(self):
        return '{}'.format(str(self.idCliente)+" "+self.nombreCliente)

class TurnoEmpleado(models.Model):
    idTurno=models.IntegerField(primary_key=True, validators=[validartamaño])
    Turno=models.CharField(max_length=30, validators=[validarnombre])
    horaEntrada=models.CharField(max_length=5, validators=[validarhora])
    horaSalida=models.CharField(max_length=5, validators=[validarhora])
    def __str__(self):
        return '{}'.format(str(self.idTurno)+" "+self.Turno)



class Planilla(models.Model):
    idPlanilla=models.IntegerField(primary_key=True, validators=[validartamaño])
    sueldoBase=models.IntegerField(validators=[validarsueldo])
    IHSS=models.IntegerField()
    RAP=models.IntegerField()

    def __str__(self):
        return '{}'.format(str(self.idPlanilla)+" "+self.sueldoBase)

class Empleado(models.Model):
    idEmpleado=models.IntegerField(primary_key=True, validators=[validartamaño])
    idTurno=models.ForeignKey(TurnoEmpleado, null=False, blank=False, on_delete=models.PROTECT)
    idPlanilla=models.ForeignKey(Planilla, null=False, blank=False, on_delete=models.PROTECT)
    nombreEmpleado=models.CharField(max_length=30,validators=[validarnombre])
    direccionEmpleado=models.TextField(max_length=100, validators=[validardireccion])
    telefonoEmpleado=models.CharField(max_length=8, validators=[validarnumero])
    def __str__(self):
        return '{}'.format(str(self.idEmpleado)+" "+self.nombreEmpleado)

class Producto(models.Model):
    idProducto=models.IntegerField(primary_key=True, validators=[validartamaño])
    nombreProducto=models.CharField(max_length=40, validators=[validarnombre])
    precioVenta=models.IntegerField(validators=[validarquenoseacero])
    precioCompra=models.IntegerField(validators=[validarquenoseacero])
    idMarca=models.ForeignKey(Marca, null=False, blank=False, on_delete=models.PROTECT)
    idCategoria=models.ForeignKey(Categoria, null=False, blank=False, on_delete=models.PROTECT)
    idGarantia=models.ForeignKey(Garantia, null=False, blank=False, on_delete=models.PROTECT)
    existencia=models.IntegerField(validators=[validarquenoseacero])
    existenciaMinima=models.IntegerField(validators=[validar_mayor_a_tres])
    def __str__(self):
        return '{}'.format(str(self.idProducto)+" "+self.nombreProducto)


class FacturaEncabezado(models.Model):
    idFacturaEncabezado=models.IntegerField(primary_key=True, validators=[validartamaño])
    idEmpleado=models.ForeignKey(Empleado, null=False, blank=False, on_delete=models.PROTECT)
    idCliente=models.ForeignKey(Cliente, null=False, blank=False, on_delete=models.PROTECT)
    idMetodoPago=models.ForeignKey(MetodoPago, null=False, blank=False, on_delete=models.PROTECT)
    idFormaPago=models.ForeignKey(FormaPago, null=False, blank=False, on_delete=models.PROTECT)
    nSar=models.CharField(max_length=15)
    fecha=models.DateTimeField(auto_now_add=True)
    codigoCAI=models.CharField(max_length=35)
    isv18=models.IntegerField()
    isv15=models.IntegerField()
    totalFactura=models.IntegerField()
    def __str__(self):
        return '{}'.format(str(self.idFacturaEncabezado)+" "+str(self.idEmpleado))

class FacturaDetalle(models.Model):
    idFacturaDetalle = models.IntegerField(primary_key=True, validators=[validartamaño])
    idFacturaEncabezado = models.OneToOneField(FacturaEncabezado, on_delete=models.PROTECT)
    idProducto=models.ForeignKey(Producto, null=False, blank=False, on_delete=models.PROTECT)
    cantidad = models.IntegerField(validators=[validarquenoseacero])

    def __str__(self):
        return '{}'.format(str(self.idFacturaDetalle))


